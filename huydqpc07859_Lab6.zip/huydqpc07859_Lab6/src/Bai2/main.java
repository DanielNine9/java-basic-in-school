/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai2;

import java.util.ArrayList;

/**
 *
 * @author huyyd
 */
public class main {
    public static void main(String[] args) {
       listSanPham list = new listSanPham();
       list.listNhap();
       list.xuat();
    }
}
