/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dinhquochuypc07859_lab8;

/**
 *
 * @author huyyd
 */
public class main {
    public static void main(String[] args) {
        System.out.println(XPoly.max(1,2,3,4));
        System.out.println(XPoly.min(1,2,3,4));
        System.out.println(XPoly.sum(1,2,3,4));
        System.out.println(XPoly.toUpperFirstChat("hello world"));
    }
}
